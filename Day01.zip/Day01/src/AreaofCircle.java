
public class AreaofCircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			float radius=5;
			
			double area=3.142*radius*radius;
			System.out.println("area of circle is:"+area);

	}

}
