
public class Program1 {

	public static void main(String[] args) {
		int a=10;
		System.out.println(a);
		
		int b=20;
		b=30;
		b=40;
		System.out.println(b);
	}

}
