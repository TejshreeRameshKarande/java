public class WrapperClass {
    public static void main(String[] args)
    {
        //Wrapper class
        int a=10;
        Integer i=new Integer(a);
        System.out.println(i);

        //conversion
        //int to double
        double d=i.doubleValue();
        System.out.println(d);

        //int to float
        float f=i.floatValue();
        System.out.println(f);

        //int to byte
        byte b=i.byteValue();
        System.out.println(b);

        //Helper function
        int max=Integer.max(10,20);
        System.out.println(max);
    }
}
