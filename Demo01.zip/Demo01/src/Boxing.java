public class Boxing{
    public static void main(String[] args) {
        int a=10;
        Integer b= a;
        System.out.println(b);
}
}
