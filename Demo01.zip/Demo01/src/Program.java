
public class Program {

	public static void main(String[] args) {
		double length = 10.00 , breadth = 2.00 , area;
		
		area = length * breadth; 
		
		System.out.println("Area : " + area);
		 
		System.out.println("Length : " + length + " breadth " + breadth);
		System.out.printf("Area : %.2f",area);
		
	}

}
