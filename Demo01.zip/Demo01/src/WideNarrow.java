public class WideNarrow{
    public static void main(String[] args){
        //widening
        byte b=10;
        short s =(byte) b;
        System.out.println("b:" +b+ "\t" +"short:"+s);

        //Auto-Widening
        short sc=b;
        System.out.println("b:" +b+ "\t" +"short:"+sc);

        //Narrowing
        short s1=10;
        byte b1=(byte)s1;
        System.out.println("s1:" +s1+ "\t" +"b1:"+b1);

    }
}