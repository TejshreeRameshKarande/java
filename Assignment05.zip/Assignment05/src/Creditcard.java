import java.util.Scanner;

class CreditAccount {
    private int accountNum;
    private double beginingBlance;
    private double charges;
    private double credits;
    private double credit_limit;

    public CreditAccount() {}

    public int getaccountNum() {
        return accountNum;
    }
    public void setaccountNum(int accountNum) {
        this.accountNum = accountNum;
    }
    public double getbeginingBlance() {
        return beginingBlance;
    }
    public void setbeginingBlance(double beginingBlance) {
        this.beginingBlance = beginingBlance;
    }
    public double getcharges() {
        return charges;
    }
    public void setcharges(double charges) {
        this.charges = charges;
    }
    public double getcredits() {
        return credits;
    }
    public void setcredits(double credits) {
        this.credits = credits;
    }
    public double getcredit_limit() {
        return credit_limit;
    }
    public void setcredit_limit(double credit_limit) {
        this.credit_limit = credit_limit;
    }

    public double newBalance() {
        return beginingBlance + charges - credits;
    }
}

class TestCreditAccount {
    CreditAccount CA = new CreditAccount();

    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter account number:");
        CA.setaccountNum(sc.nextInt());
        System.out.println("Enter balance at the beginning of the month:");
        CA.setbeginingBlance(sc.nextDouble());
        System.out.println("Enter total of all items charged by the customer this month:");
        CA.setcharges(sc.nextDouble());
        System.out.println("Enter total of all credits applied to the customer’s account this month:");
        CA.setcredits(sc.nextDouble());
        System.out.println("Enter allowed credit limit:");
        CA.setcredit_limit(sc.nextDouble());
    }

    public void printRecord() {
        System.out.println("Account Number: " + CA.getaccountNum() +
                "\nBalance at the beginning of the month: " + CA.getbeginingBlance() +
                "\nCharges this month: " + CA.getcharges() +
                "\nCredits applied this month: " + CA.getcredits() +
                "\nAllowed credit limit: " + CA.getcredit_limit());
    }
}

public class Creditcard {
    public static void main(String[] args) {
        TestCreditAccount TA = new TestCreditAccount();
        TA.acceptRecord();
        TA.printRecord();

        double newBal = TA.CA.newBalance();
        double credit_limit = TA.CA.getcredit_limit();

        System.out.println("New Balance is: " + newBal);

        if (newBal > credit_limit) {
            System.out.println("Customer exceeds the Limit!!");
        } else {
            System.out.println("Customer is within the credit limit.");
        }
    }
}
