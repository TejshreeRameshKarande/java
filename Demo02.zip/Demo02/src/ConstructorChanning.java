class Person{
	private String name;
	private int age;
	public Person()
	{
		this("Tejshree",20);
	}
	public Person(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	public void printRecord()
	{
		System.out.println("name:"+this.name);
		System.out.println("age:"+this.age);
	}
}
public class ConstructorChanning {

	public static void main(String[] args) {
		Person p=new Person();
		p.printRecord();

	}

}
