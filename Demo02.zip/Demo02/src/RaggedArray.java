
public class RaggedArray {

	public static void main(String[] args) {
		//double[][] arr=new double[][] {{1,2,3},{4,5,6}};
		
		int[][] rarr=new int[3][];
		
		rarr[0]=new int[1];
		rarr[1]=new int[2];
		rarr[2]=new int[3];
		
		for(int i=0;i<2;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(rarr[i][j]+" ");
			}
			System.out.println();
		}
		int num=0;
		for(int i=0;i<rarr.length;i++) {
			for(int j=0;j<rarr.length;j++) {
				rarr[i][j]=++num;
			}
		}
		for(int i=0;i<2;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(rarr[i][j]+" ");
			}
			System.out.println();
		}
	}

}
