import java.util.Calendar;
import java.util.Scanner;

class Date{
	private int day;
	private int month;
	private int year;
	
	public Date()
	{
		Calendar c = Calendar.getInstance();
		day=c.get(Calendar.DATE);
		month=c.get(Calendar.MONTH)+1;
		year=c.get(Calendar.YEAR);
	}
	public Date(int day,int month,int year) {
		System.out.println("public Date(int day,int month,int year)");
		this.day=day;
		this.month=month;
		this.year=year;
	}
	public void acceptRecord()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Day:");
		day=sc.nextInt();
		System.out.println("Month:");
		month=sc.nextInt();
		System.out.println("Year:");
		year=sc.nextInt();
	}
	public void printRecord()
	{
		System.out.println("Day:"+this.day);
		System.out.println("Month:"+this.month);
		System.out.println("Year:"+this.year);
	}
}
public class ConstructorType {

	public static void main(String[] args) {
		Date dt1=new Date();
		dt1.acceptRecord();
		dt1.printRecord();
		
		Date dt2=new Date(23,9,2005);
		dt2.printRecord();
		

	}

}
