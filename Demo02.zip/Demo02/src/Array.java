import java.util.Scanner;
public class Array {

	public static void main(String[] args) {
		int[] arr= {10,20,30,40,50};
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
		Scanner sc=new Scanner(System.in);
		
		double[] array=new double[3];
		System.out.println("Enter the numbers:");
		for(int i=0;i<array.length;i++)
		{
			array[i]=sc.nextDouble();
		}
		double sum=Array.arraySum(array);
		
		System.out.println("sum:"+sum);
	}
	
	public static double arraySum(double[] arr)
	{
		double total=0.0;
		for(int i=0;i<arr.length;i++)
		{
			total=total+arr[i];
		}
		return total;

	}

}
