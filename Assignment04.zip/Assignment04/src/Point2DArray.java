import java.util.Scanner;

class Point2D{
	private int x,y;
	
	public Point2D(int x,int y) {
		this.x=x;
		this.y=y;
	}
	public String getDetails() {
		return "("+x+","+y+")";
	}
	public boolean isEqual(Point2D other) {
		return this.x == other.x && this.y == other.y;
	}
	public double calculateDistance(Point2D other) {
		int dx=this.x-other.x;
		int dy=this.y-other.y;
		return Math.sqrt(Math.pow(dx,2)+Math.pow(dy,2));
	}
}
	public class Point2DArray{
	
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter x and y for point 1:");
			Point2D p1=new Point2D(sc.nextInt(),sc.nextInt());
			System.out.println("Enter x and y for point 2:");
			Point2D p2=new Point2D(sc.nextInt(),sc.nextInt());
			
			System.out.println("Point p1: "+p1.getDetails());
			System.out.println("Point p2: "+p2.getDetails());
			
			if(p1.isEqual(p2)){
				System.out.println("P[oints are same!!");
			}
			else {
				System.out.println("Points are different!!");
				System.out.println("Distance:"+p1.calculateDistance(p2));
			}
			
			System.out.println("For Multiple Points:");
			System.out.println("How many points you points?");
			int n =sc.nextInt();
			Point2D[] points=new Point2D[n];
			
			for(int i=0;i<n;i++) {
				System.out.println("Enter x and y for points"+i+":");
				points[i]=new Point2D(sc.nextInt(),sc.nextInt());
			}
			while(true) {
				System.out.println("\nMenu.\n1.Display details of a specific point."
						+ "\n2.Display x, y co-ordinates of all points."
						+ "\n3.Distance between 2 points.\n4.Exit");
				System.out.println("Enter your choice:");
				int choice=sc.nextInt();
				
			switch(choice) {
				case 1:
					System.out.println("Enter Index:");
					int idx=sc.nextInt();
					if(idx>=0 && idx<=points.length) {
						System.out.println("Points["+idx+"]="+points[idx].getDetails());
					}
					else {
						System.out.println("Invalide index!!Please retry!!");
					}
					break;
					
				case 2:
					for(int i=0;i<points.length;i++) {
						System.out.println("Points["+i+"]="+points[i].getDetails());
					}
					break;
					
				case 3:
					System.out.println("Enter 2 indices:");
					int i1=sc.nextInt();
					int i2=sc.nextInt();
					
					if(i1>=0 && i1<n && i2>=0 && i2<n) {
						if(!points[i1].equals(points[i2])) {
							double dist=points[i1].calculateDistance(points[i2]);
							System.out.println("Distance:"+dist);
						}
						else {
							System.out.println("Both oints are at same location!");
						}
					}
					else {
						System.out.println("Invalid Indices!");
					}
					break;
					
				case 4:
					System.out.println("Exit....!");
					sc.close();
					return;
					
				default:
					System.out.println("Invalid choice!!");
			}
			}
		}
	}