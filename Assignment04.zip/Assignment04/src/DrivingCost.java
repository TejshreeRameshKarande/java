import java.util.Scanner;

public class DrivingCost {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter miles driven per day:");
		double Milesperday=sc.nextDouble();
		
		System.out.println("Enter Cost per gallon of gasoline:");
		double costperGallon=sc.nextDouble();
		
		System.out.println("Enter Average miles per gallon:");
		double avarageMilesgallon=sc.nextDouble();
		
		System.out.println("Enter Parking fees per day:");
		double parkingFees=sc.nextDouble();
		
		System.out.println("Enter Tolls per day.:");
		double tollsperday=sc.nextDouble();
		
		double totalGallon=Milesperday/costperGallon;
		
		double costOfGallon=totalGallon*costperGallon;
		
		double CostperDay=costOfGallon+parkingFees+tollsperday;
		System.out.println("cost per day of driving to work:"+CostperDay);
		
		}

}
