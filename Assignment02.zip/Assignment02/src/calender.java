
import java.util.Scanner;
class Date{
	private int day;
	private int month;
	private int year;
	
	public Date() {
		
	}
	public Date(int day,int month,int year) {
		this.day=day;
		this.month=month;
		this.year=year;
	}
	public int getday() {
		return day;
	}
	public void setday(int day) {
		this.day=day;
	}
	public int getmonth() {
		return month;
	}
	public void setmonth(int month) {
		this.month=month;
	}
	public int getyear() {
		return year;
	}
	public void setyear(int year) {
		this.year=year;
	}
}
class TestDate{
	Date dt=new Date();
	public void acceptRecord()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Day:");
		dt.setday(sc.nextInt());
		System.out.println("Month:");
		dt.setmonth(sc.nextInt());
		System.out.println("Year:");
		dt.setyear(sc.nextInt());
	}
	public void printRecord()
	{
		System.out.println(dt.getday()+"/"+dt.getmonth()+"/"+dt.getyear());
	}
}
public class calender {

	public static void main(String[] args) {
		TestDate D=new TestDate();
		D.acceptRecord();
		D.printRecord();
		

	}

}
