import java.util.Scanner;

class Invoice1{

	private String apartNo;

	private String apartDes;

	private int items;

	private double price;

	

	public Invoice1() {

		

	}

	public Invoice1(String apartNo,String apartDes,int items,double price) {

		this.apartNo=apartNo;

		this.apartDes=apartDes;

		this.items=items;

		this.price=price;

	}

	public String getApartNo() {

		return apartNo;

	}

	public void setApartNo(String apartNo) {

		this.apartNo=apartNo;

	}

	public String getApartDes() {

		return apartDes;

	}

	public void setApartDes(String apartDes) {

		this.apartDes=apartDes;

	}

	public int  getItems() {

		return items;

	}

	public void setItems(int items) {

		this.items=items;

	}

	public double  getPrice() {

		return price;

	}

	public void setPrice(double price) {

		this.price=price;

	}

}



class TestInvoice1{

	Invoice1 i1=new Invoice1();

	public void acceptRecord() {

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter apart number:");

		i1.setApartNo(sc.nextLine());

		System.out.println("Enter apartment description:");

		i1.setApartDes(sc.nextLine());

		System.out.println("Enter number of itemns:");

		i1.setItems(sc.nextInt());

		System.out.println("Enter price :");

		i1.setPrice(sc.nextDouble());

		}

	public void printRecord() {

		System.out.println("Number of items:"+i1.getItems());

		if(i1.getItems()>0) {

			System.out.println("You have entered positive count of items!!");

		}

		else {

			System.out.println("You have entered negative value of items!!");

		}

		System.out.println("Price is:"+i1.getPrice());

		if(i1.getPrice()>0) {

			System.out.println("Total price is:"+i1.getPrice()*i1.getItems());

		}

		else {

			System.out.println("you have entered negative value of price!!");

		}

	}

}

public class Invoice {



	public static void main(String[] args) {

		Invoice1 i=new Invoice1();

		TestInvoice1 i2=new TestInvoice1();

		i2.acceptRecord();

		i2.printRecord();



	}



}