import java.util.Scanner;

class Point {
    private double X;
    private double Y;

    public Point() {
    }

    public Point(double x, double y) {
        this.X = x;
        this.Y = y;
    }

    public double getX() {
        return X;
    }

    public void setX(double X) {
        this.X = X;
    }

    public double getY() {
        return Y;
    }

    public void setY(double Y) {
        this.Y = Y;
    }

    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);
        System.out.print("X: ");
        X = sc.nextDouble();
        System.out.print("Y: ");
        Y = sc.nextDouble();
    }

    public void display() {
        System.out.println("X: " + this.X + "\tY: " + this.Y);
    }

    public String getDetails() {
        return "(" + this.X + ", " + this.Y + ")";
    }

    public boolean isEqual(Point other) {
        return this.X == other.X && this.Y == other.Y;
    }
    public double calculateDiastance(Point other) {
    	return Math.sqrt(Math.pow(this.X-other.Y,2)+(Math.pow(this.X-other.Y,2)));
    }
}

public class Point2D {
    public static void main(String[] args) {
        Point pt1 = new Point();
        System.out.println("Enter for Point 1:");
        pt1.acceptRecord();
        pt1.display();

        Point pt2 = new Point();
        System.out.println("Enter for Point 2:");
        pt2.acceptRecord();
        pt2.display();

        System.out.println("Point 1 details: " + pt1.getDetails());
        System.out.println("Point 2 details: " + pt2.getDetails());

        if (pt1.isEqual(pt2)) {
            System.out.println("Both points are equal.");
        }
        else {
        	double distance=pt1.calculateDiastance(pt2);
            System.out.println("Points are not equal.\nThe Distance is:"+distance);
        }
        
    }
}
