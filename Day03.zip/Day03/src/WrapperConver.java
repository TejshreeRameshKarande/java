import java.util.Scanner;
public class WrapperConver{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Number:");
        int num=sc.nextInt();
        System.out.println("Given Number:"+num);

        //binary
        String binary = Integer.toBinaryString(num);
        System.out.println("Binary Number:"+binary);
        
        //octal
        String octal = Integer.toOctalString(num);
        System.out.println("Octal Number:"+octal);

        //hexadecimal
        String hexa = Integer.toHexString(num);
        System.out.println("Hexadecimal Number:"+hexa);
}   

}